package _SD_SOCKET;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Iterator;
import java.util.Scanner;

public class Cliente {
	private Socket socket;
	
	public Cliente() throws UnknownHostException, IOException {
		this.socket = new Socket("localhost", 5000);
		init();
	}
	
	private void init() throws IOException {
		System.out.println(readMesagge());
		System.out.println(readMesagge());
		String[] list = readMesagge().split("-");
		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i]);
		}
		System.out.println(readMesagge());
		socket.getOutputStream().write(readConsole());
		System.out.println(readMesagge());
	}
	
	private int readConsole() {
		Scanner scan = new Scanner(System.in);
		int number= scan.nextInt();
		return number;
	}
	
	private String readMesagge() throws IOException {
		int size = socket.getInputStream().read();
		int byt = 0;
		String msg ="";
		for (int i = 0; i < size; i++) {
			byt = socket.getInputStream().read();
			msg += (char)byt;
		}
		return msg;
	}
	
	
	public static void main(String[] args) {
		try {
			new Cliente();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
