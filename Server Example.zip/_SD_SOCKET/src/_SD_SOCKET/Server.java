package _SD_SOCKET;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Logger;

public class Server {

	private ServerSocket serversocket;
	
	public Server() throws IOException {
		this.serversocket = new ServerSocket(5000);
		Logger.getGlobal().info("Servidor ejecutandose en puerto 5000");
		Thread thread = new Thread( new Runnable() {
			@Override
			public void run() {
				while (!serversocket.isClosed()) {
					try {
						Socket connection = serversocket.accept();
						Logger.getGlobal().info("nueva conexion aceptada");
						menu(connection);
						
						
					} catch (Exception e) {
						e.printStackTrace();
					}
					
					
				}
				
			}
		});
		thread.start();
	}
	
	private void menu(Socket socket) throws IOException {
		String[] list = {"Fresa", "Manzana", "Pera", "Papaya", "Durazno", "Naranja", "Mandarina", "Uva", "Granadilla", "Mango"};
		String bienvenida = "Bienvenido Usuario";
		writeMsg(socket, bienvenida);
		String mensaje1 = "A continuacion se muestra una lista";
		writeMsg(socket, mensaje1);
		String l = "";
		for (int i = 0; i < list.length; i++) {
			l += i+". " + list[i] + "-";
		}
		writeMsg(socket, l);
		String mensaje2 = "Ingrese el numero que corresponde para seleccionar una fruta";
		writeMsg(socket, mensaje2);
		int position = socket.getInputStream().read();
		if (position >= list.length) {
			writeMsg(socket, "el numero ingresado no correponde a ninguna opcion");
		}else {
			String mensaje3 = "La fruta seleccionada es : " + list[position];
			writeMsg(socket, mensaje3);
		}

	}
	
	private void writeMsg(Socket socket,String msg) throws IOException {
		socket.getOutputStream().write(msg.length());
		socket.getOutputStream().write(msg.getBytes());
	}
	
	public static void main(String[] args) {
		try {
			new Server();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
